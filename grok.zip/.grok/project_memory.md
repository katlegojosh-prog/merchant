- REFINER project: ongoing product-improvement system focused on engagement metrics/analytics, refinement process, and content/UX engagement boosts [2026-11-27]
- Target product under REFINER: THE MERCHANT (https://site-4e1ee156b0a44ea8ab47281d9e029b42.freebuff.page/) — PWA expiry tracker for small shops (barcode scan, expiry urgency, status close-out, roles, digest, team) [2026-11-27]
- Executed full improvement plan artifacts: REFINER_Merchant_Execution_Pack.docx (plan + metrics definitions + event schema) and REFINER_Merchant_Backlog.xlsx (30-item prioritised backlog, metrics tracker, event catalog, phase summary) saved to artifacts/ [2026-11-27]
- Phase 0 automated: REFINER_Merchant_Event_Schema.sql (engagement_events table, indexes, RLS, metric views, shelf_health_score function) + backlog updated (M-001/M-002 Spec Ready, M-003 Done) + Implementation sheet with React track() helper [2026-11-27]
- Full Phases 0–4 rendered: REFINER_Merchant_Full_Phases_Guide.docx (master implementation guide), all 30 backlog items elevated to Spec Complete with detailed acceptance criteria, REFINER_Merchant_Phase2_Settings.sql, Implementation sheet rewritten [2026-11-27]
- Advanced Analytics layer: REFINER_Merchant_Advanced_Analytics.docx + .sql (diagnostic/predictive/prescriptive metrics, snapshots, funnel, priority close list, risk score); backlog Engagement Metrics expanded + new Advanced Analytics sheet [2026-11-27]
- Highest Leverage Pack: REFINER_Merchant_Highest_Leverage_Pack.docx with exact execution order, track() code, Health Score + Priority Close List contracts, Phase 1 UX specs; M-001/002/004/005/006/009/010 marked In Progress — Pack Ready [2026-11-27]
- Implementation package built under artifacts/implementation/: track.ts, analytics.ts, HealthScoreCard, PriorityCloseList, EmptyStates, CoachMarks, haptics, continuousScan + README + DEPLOYMENT checklist; backlog items marked Impl Package Ready [2026-11-27]






